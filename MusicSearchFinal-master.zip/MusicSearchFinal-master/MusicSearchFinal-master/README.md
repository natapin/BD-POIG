# MusicSearchFinal
App imitating spotify searching bar.
C# WPF MVVM, MySQL database
